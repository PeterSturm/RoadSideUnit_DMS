package main.java.sturm.snmp.agent;

import org.snmp4j.agent.BaseAgent;
import org.snmp4j.agent.mo.snmp.SnmpCommunityMIB;
import org.snmp4j.agent.mo.snmp.SnmpNotificationMIB;
import org.snmp4j.agent.mo.snmp.SnmpTargetMIB;
import org.snmp4j.agent.mo.snmp.VacmMIB;

public class Agent extends BaseAgent {

    public Agent(){

    }

    @Override
    protected void addCommunities(SnmpCommunityMIB arg0) {

    }

    @Override
    protected void addNotificationTargets(SnmpTargetMIB arg0, SnmpNotificationMIB arg1) {

    }

    @Override
    protected void addViews(VacmMIB arg0) {

    }

    @Override
    protected void registerManagedObjects() {

    }

    @Override
    protected void unregisterManagedObjects() {

    }

    @Override
    protected void addUsmUser(USM arg0){

    }

}